import edu.cs3500.spreadsheets.model.BasicWorkSheet;
import edu.cs3500.spreadsheets.model.Cell;
import edu.cs3500.spreadsheets.model.Coord;
import edu.cs3500.spreadsheets.model.Spreadsheet;
import edu.cs3500.spreadsheets.sexp.SBoolean;
import edu.cs3500.spreadsheets.sexp.SList;
import edu.cs3500.spreadsheets.sexp.SNumber;
import edu.cs3500.spreadsheets.sexp.SString;
import edu.cs3500.spreadsheets.sexp.SSymbol;
import edu.cs3500.spreadsheets.sexp.Sexp;
import java.util.ArrayList;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CellTest {

  //the .getItem methods get the item of type Sexp, and used .toString method to return string form
  //of the Sexp object
  @Test
  public void testCellSBoolean(){
    Sexp test = new SBoolean(false);
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=false").createCell(1, 2, "world").createWorksheet();
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
  }

  @Test
  public void testCellSNumber(){
    Sexp test = new SNumber(2.0);
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=2").createCell(1, 2, "world").createWorksheet();
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
  }

  @Test
  public void testCellSSymbol(){
    Sexp test = new SSymbol("SUM");
    Cell test2 = new Cell(new Coord(1, 1), test.toString());
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "SUM").createCell(1, 2, "world").createWorksheet();
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
  }

  @Test
  public void testCellSList(){
    ArrayList<Sexp> contents = new ArrayList<>();
    contents.add(new SSymbol("SUM"));
    contents.add(new SNumber(2.0));
    contents.add(new SNumber(4.0));
    Sexp test = new SList(contents);
    Cell test2 = new Cell(new Coord(1, 1), test.toString());
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=(SUM 2 4)").createCell(1, 2, "world").createWorksheet();
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
  }

  @Test
  public void testCellSString(){
    Sexp test = new SString("hello");
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=\"hello\"").createCell(1, 2, "world").createWorksheet();
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
    assertEquals(test.toString(), s.getCellAt(1, 1).getItem());
  }

  //Test blank cell
  @Test
  public void testBlankCell(){
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .blankCell(1, 1).createCell(1, 2, "world").createWorksheet();

    assertEquals("",s.getCellAt(1, 1).toString());
  }

  //Test PRODUCTs
  @Test
  public void testProductSymbol(){
    ArrayList<Sexp> contents = new ArrayList<>();
    contents.add(new SSymbol("PRODUCT"));
    contents.add(new SNumber(2.0));
    contents.add(new SNumber(4.0));
    Sexp test = new SList(contents);
    Sexp result = new SNumber(8.0);
    Cell compare = new Cell(new Coord(1,1), result.toString());
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=(PRODUCT 2 4)").createCell(1, 2, "world").createWorksheet();
    assertEquals(compare.getItem(), s.getCellAt(1, 1).getItem() );
  }
  //Test SUM
  @Test
  public void testSumSymbol(){
    ArrayList<Sexp> contents = new ArrayList<>();
    contents.add(new SSymbol("SUM"));
    contents.add(new SNumber(2.0));
    contents.add(new SNumber(4.0));
    Sexp test = new SList(contents);
    Sexp result = new SNumber(6.0);
    Cell compare = new Cell(new Coord(1,1), result.toString());
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=(SUM 2 4)").createCell(1, 2, "world").createWorksheet();
    assertEquals(compare.getItem(), s.getCellAt(1, 1).getItem() );
  }
  //Test
  @Test
  public void testLessThanSymbol(){
    ArrayList<Sexp> contents = new ArrayList<>();
    contents.add(new SSymbol("SUM"));
    contents.add(new SNumber(2.0));
    contents.add(new SNumber(4.0));
    Sexp test = new SList(contents);
    Sexp result = new SBoolean(true);
    Cell compare = new Cell(new Coord(1,1), result.toString());
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=(< 2 4)").createCell(1, 2, "world").createWorksheet();
    assertEquals(compare.getItem(), s.getCellAt(1, 1).getItem() );
  }
  //Test alphabetize


  //Test formula that refers to a cell twice (SUM A1 A1)
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalReference(){
    Spreadsheet s = BasicWorkSheet.defaultBuilder().setHeight(3).setWidth(3).setGrid()
        .createCell(1, 1, "=(SUM A1 A1)").createCell(1, 2, "world").createWorksheet();

    
  }


  //Test region (SUM A1:A5)

  //Test (SUM TRUE 5)

  //Test toString of values




}

